# coding=utf-8

import psycopg2

# 创建连接
conn = psycopg2.connect(host='localhost', user='root', password='123456', dbname='postgre', port=8081)

# 获取游标
cursor = conn.cursor()

# 执行语句
cursor.execute("SELECT * from pg_buffercache")

# 获取结果：支持fetchone, fetchall和fetchmany
res = cursor.fetchone()
print(res)

# 关闭连接
conn.close()